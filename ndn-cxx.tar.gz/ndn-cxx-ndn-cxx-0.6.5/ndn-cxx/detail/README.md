# Implementation Detail

This folder contains implementation detail of ndn-cxx library.
Declarations contained in these files are not considered public API and they can change without notice.

Headers in this folder are installed to the target system.
