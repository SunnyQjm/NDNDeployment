ndn-cxx authors
===============

## The primary authors are (and/or have been):

* Alexander Afanasyev   <http://lasr.cs.ucla.edu/afanasyev/index.html>
* Yingdi Yu             <http://irl.cs.ucla.edu/~yingdi/>
* Junxiao Shi           <http://www.cs.arizona.edu/people/shijunxiao/>
* Jeff Thompson         <jefft0@remap.ucla.edu>
* Zhenkai Zhu           <http://irl.cs.ucla.edu/~zhenkai/>

## All project authors and contributors

The following is an inevitably incomplete list of MUCH-APPRECIATED CONTRIBUTORS,
people who have reported bugs, submitted patches, and implemented new features
in the library:

* Wentao Shang          <http://irl.cs.ucla.edu/~wentao/>
* Steve DiBenedetto     <http://www.cs.colostate.edu/~dibenede/>
* Davide Pesavento      <https://www.linkedin.com/in/davidepesavento>
* Syed Obaid Amin       <http://obaidamin.weebly.com/>
* Shuo Chen             <chenatu2006@gmail.com>
* Hila Ben Abraham      <http://research.engineering.wustl.edu/~abrahamh/>
* Xingyu Ma             <http://www.linkedin.com/pub/xingyu-ma/1a/384/5a8>
* Michael Sweatt        <https://www.linkedin.com/in/michaelsweatt>
* Lixia Zhang           <http://www.cs.ucla.edu/~lixia/home.html>
* Jeff Burke            <http://remap.ucla.edu/jburke/>
* Xiaoke Jiang          <http://netarchlab.tsinghua.edu.cn/~shock/>
* Jiewen Tan            <alanwake@ucla.edu>
* Vince Lehman          <http://vslehman.com>
* Mathias Gibbens       <gibmat@cs.arizona.edu>
* Chengyu Fan           <chengyu@cs.colostate.edu>
* Qiuhan Ding           <http://irl.cs.ucla.edu/~qiuhanding/>
* Spyridon Mastorakis   <http://cs.ucla.edu/~mastorakis/>
* Eric Newberry         <http://cs.arizona.edu/~enewberry/>
* João Pereira          <http://website.jpereira.co.uk>
* Mickey Sweatt         <https://www.linkedin.com/in/michaelsweatt>
* Yanbiao Li            <https://www.linkedin.com/pub/yanbiao-li/24/7a1/4ba>
* Marcin Juszkiewicz    <http://marcin.juszkiewicz.com.pl/>
* Susmit Shannigrahi    <https://www.linkedin.com/in/susmit-shannigrahi-90433b8>
* José Quevedo          <http://atnog.av.it.pt/members/jquevedo>
* Zhiyi Zhang           <http://irl.cs.ucla.edu/~zhiyi/>
* Chavoosh Ghasemi      <https://www.linkedin.com/in/chavoosh-ghasemi-421327117/>
