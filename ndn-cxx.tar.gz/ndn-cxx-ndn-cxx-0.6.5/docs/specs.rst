Specifications
==============

.. toctree::
   :maxdepth: 2

   specs/signed-interest
   specs/certificate-format
   specs/safe-bag
   specs/validation-error-code
