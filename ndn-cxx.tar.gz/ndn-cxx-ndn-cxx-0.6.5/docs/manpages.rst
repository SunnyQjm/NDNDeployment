Manpages
========

.. toctree::
    ndn-client.conf     <manpages/ndn-client.conf>
    ndn-cxx logging     <manpages/ndn-log>
    manpages/ndnsec
    ndnsec-list         <manpages/ndnsec-list>
    ndnsec-get-default  <manpages/ndnsec-get-default>
    ndnsec-set-default  <manpages/ndnsec-set-default>
    ndnsec-key-gen      <manpages/ndnsec-key-gen>
    ndnsec-sign-req     <manpages/ndnsec-sign-req>
    ndnsec-cert-gen     <manpages/ndnsec-cert-gen>
    ndnsec-cert-install <manpages/ndnsec-cert-install>
    ndnsec-cert-dump    <manpages/ndnsec-cert-dump>
    ndnsec-delete       <manpages/ndnsec-delete>
    ndnsec-export       <manpages/ndnsec-export>
    ndnsec-import       <manpages/ndnsec-import>
    ndnsec-unlock-tpm   <manpages/ndnsec-unlock-tpm>
    :maxdepth: 1
