ChronoSync - A synchronization Protocol in NDN
==============================================

.. toctree::
   :hidden:
   :maxdepth: 3

   DesignDoc

* :doc:`DesignDoc`

**Additional documentation**

* `API documentation (doxygen) <doxygen/annotated.html>`_

Downloading
-----------

* `Source code GitHub git repository <https://github.com/named-data/ChronoSync>`_.

License
-------

ChronoSync is free software: you can redistribute it and/or modify it under the terms
of the GNU General Public License as published by the Free Software Foundation, either
version 3 of the License, or (at your option) any later version.
