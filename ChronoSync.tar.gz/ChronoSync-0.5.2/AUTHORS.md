ChronoSync authors
==================

- Zhenkai Zhu         <http://irl.cs.ucla.edu/~zhenkai/>
- Alexander Afanasyev <http://lasr.cs.ucla.edu/afanasyev/index.html>
- Chaoyi Bian         <bcy@pku.edu.cn>
- Yingdi Yu           <http://irl.cs.ucla.edu/~yingdi/web/index.html>
- Sonu Mishra         <https://www.linkedin.com/in/mishrasonu>
