PSync authors
=============

## Main Project Author(s):

The University of Memphis:

* Ashlesh Gawande <https://www.linkedin.com/in/agawande>
* Minsheng Zhang  <https://www.linkedin.com/in/minsheng-zhang-032023a1>
* Lan Wang <http://www.cs.memphis.edu/~lanwang/>

## Contributer(s):

* Junxiao Shi <https://www.linkedin.com/in/shijunxiao>

## Technical advisor(s):

* Lan Wang <http://www.cs.memphis.edu/~lanwang/>

## Special thanks to:

* Davide Pesavento <https://www.linkedin.com/in/davidepesavento>