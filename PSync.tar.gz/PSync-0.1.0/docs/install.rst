PSync Installation Instructions
===============================

.. toctree::
..

Prerequisites
-------------

-  `ndn-cxx <https://named-data.net/doc/ndn-cxx>`_ and its dependencies

Build
-----

Execute the following commands to build PSync:

::

    ./waf configure
    ./waf
    sudo ./waf install