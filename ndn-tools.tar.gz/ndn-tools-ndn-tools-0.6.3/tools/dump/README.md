# ndndump

**ndndump** is a traffic analysis tool that captures Interest, Data, and Nack packets on the wire
and displays brief information about captured packets.

Usage example:

1. start NFD on local machine
2. create an IPv4 UDP tunnel to a remote machine
3. cause some traffic going on the tunnel
4. execute `sudo ndndump`

For more information, consult the manpage.
