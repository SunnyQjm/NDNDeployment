# ndn-tools authors

## All project authors and contributors

The following is an inevitably incomplete list of MUCH-APPRECIATED CONTRIBUTORS,
people who have reported bugs, submitted patches, and implemented new features
in ndn-tools:

* Jerald Paul Abraham   <http://www.cs.arizona.edu/people/jeraldabraham/>
* Alexander Afanasyev   <http://lasr.cs.ucla.edu/afanasyev/index.html>
* Davide Pesavento      <https://www.linkedin.com/in/davidepesavento>
* Junxiao Shi           <http://www.cs.arizona.edu/people/shijunxiao/>
* Eric Newberry         <http://cs.arizona.edu/~enewberry/>
* Xiaoke Jiang          <http://netarchlab.tsinghua.edu.cn/~shock/>
* Yingdi Yu             <http://irl.cs.ucla.edu/~yingdi/>
* Qi Zhao               <https://www.linkedin.com/pub/qi-zhao/73/835/9a3>
* Seunghyun Yoo         <http://relue2718.com/>
* Seungbae Kim          <https://sites.google.com/site/sbkimcv/>
* Wentao Shang          <http://irl.cs.ucla.edu/~wentao/>
* Steve DiBenedetto     <https://dibenede.github.io>
* Andrea Tosatto        <https://linkedin.com/in/tosattoandrea>
* Vince Lehman          <http://vslehman.com>
* Weiwei Liu            <https://www.linkedin.com/in/weiweiliu10>
* Zipeng Wang
* Qianshan Yu
* Chavoosh Ghasemi
