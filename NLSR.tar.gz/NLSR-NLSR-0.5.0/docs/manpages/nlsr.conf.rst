nlsr.conf
=========

Description
-----------

NLSR config file

Example
-------

.. literalinclude:: ../../nlsr.conf
   :linenos:
