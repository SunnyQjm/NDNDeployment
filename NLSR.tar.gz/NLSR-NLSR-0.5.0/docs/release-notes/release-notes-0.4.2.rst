NLSR version 0.4.2
++++++++++++++++++

**Bug Fixes**:

- Fix segfault in scheduled erase of lsa segment (:issue:`4520`)
