NLSR version 0.2.2 (changes since version 0.2.1)
++++++++++++++++++++++++++++++++++++++++++++++++

Release date: January 5, 2016

**Code changes**:

- Adapt code to changes in NFD/ndn-cxx version 0.4.0 release