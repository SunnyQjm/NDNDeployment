NLSR Release Notes
==================

.. include:: release-notes-latest.rst