NFD Release Notes
=================

.. include:: release-notes-latest.rst
